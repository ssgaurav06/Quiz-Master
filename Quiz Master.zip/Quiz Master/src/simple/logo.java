/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package simple;

/**
 *
 * @author Rj
 */
public class logo {
 
    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


        

    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      System.out.println("\t\t''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''");
      System.out.println("\t\t''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''");
      System.out.println("\t\t''       __       _ ___         __ __________________           __ ________________     ''");
      System.out.println("\t\t''     /|  |     / /  /      / |  |_______________   |        /|  |________________|    ''");
      System.out.println("\t\t''    | |  |    / /  /       | |  |_____________ /|  |       | |  |________________/    ''");
      System.out.println("\t\t''    | |  |   / /  /        | |  |             | |  |       | |  |                     ''");
      System.out.println("\t\t''    | |  |  / /  /         | |  |             | |  |       | |  |                     ''");
      System.out.println("\t\t''    | |  | / /  /          | |  |             | |  |       | |  |                     ''");
      System.out.println("\t\t''    | |  |/ /  /           | |  |_____________|_|  |       | |  |                     ''");
      System.out.println("\t\t''    | |  | /  /            | |  |________________  |       | |  |                     ''");
      System.out.println("\t\t''    | |  |/\\  \\            | |  |______________/|  |       | |  |                     ''");
      System.out.println("\t\t''    | |  |\\ \\  \\           | |  |             | |  |       | |  |                     ''");
      System.out.println("\t\t''    | |  | \\ \\  \\          | |  |             | |  |       | |  |                     ''");
      System.out.println("\t\t''    | |  |  \\ \\  \\         | |  |             | |  |       | |  |                     ''");
      System.out.println("\t\t''    | |  |   \\ \\  \\        | |  |_____________|_|  |       | |  |________________     ''");
      System.out.println("\t\t''    | |__|    \\ \\__\\       | |__|__________________|       | |__|________________|    ''");
      System.out.println("\t\t''    |/__ /     \\/__/       |/__ /_________________/        |/__ /_______________/     ''");
      System.out.println("\t\t''                                                                                      ''");
      System.out.println("\t\t''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''");
      System.out.println("\t\t''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''\n\n\n");
   
    
    
    }
   
    
    
    
}


