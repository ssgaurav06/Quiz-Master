# KBC -Kaun Banega Crorepati
It is Core Java based Game based on Indian television game show having best animation as possible in Core java.It is around 5000+ Line projects created for Practicing your quizzing skills.This Core java project have some amazing concepts Like Random question,All Life 
works fine,30 seconds to give answer and many more...

This project is created by Rox Studio developer Just for Fun.


# Features
+ You have 7 Lifeline to give a Answer(Same as Provided on Television Show)
+ You will get unique question everytime
+ You have 30 second to give answer
+ Your score is Stored to Database
+ You can use Practise zone for Practicing your General knowledge
+ You can watch your high Score




# How to Run KBC- kaun Banega Crorepati
First Install netbeans and mysql (ENTER MYSQL PASSWORD:-12345) on  your computer





 MySQL Changes                              
-----------------------

+ After installing mysql Open it

+ Enter the command given below in Mysql

   create database kbc;

   use kbc;

   create table score(regid int(10) primary key auto_increment,name char(40),age int(3),score int(10));
+ Done


Netbeans
-----------------------
+ Open NetBeans

+ goto Service and connect kbc database.

+ then open project Simple

+ Run and Enjoy

# Requirements

Operating System  :-Platform Independent(win,linux,mac etc)

Software required :-Java Runtime Environment (JRE).

Library           :-mysql-connector-java-5.1.23-bin.jar

# Thankyou


